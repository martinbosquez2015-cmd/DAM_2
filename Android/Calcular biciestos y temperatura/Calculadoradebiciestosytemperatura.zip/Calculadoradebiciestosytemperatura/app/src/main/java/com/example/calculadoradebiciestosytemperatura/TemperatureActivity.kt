package com.example.calculadoradebiciestosytemperatura

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.calculadoradebiciestosytemperatura.databinding.ActivityTemperatureBinding

class TemperatureActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTemperatureBinding
    private val units = arrayOf("Celsius (°C)", "Fahrenheit (°F)", "Kelvin (K)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTemperatureBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Calculadora de Temperatura"

        // Configurar los Spinners con las unidades
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, units)
        binding.spinnerFrom.adapter = adapter
        binding.spinnerTo.adapter = adapter

        binding.btnConvert.setOnClickListener {
            val tempInput = binding.etTemperature.text.toString()

            if (tempInput.isNotEmpty()) {
                val tempValue = tempInput.toDouble()
                val fromUnit = binding.spinnerFrom.selectedItem.toString()
                val toUnit = binding.spinnerTo.selectedItem.toString()

                val result = convertTemperature(tempValue, fromUnit, toUnit)
                binding.tvTempResult.text = String.format("Resultado: %.2f", result)
            } else {
                Toast.makeText(this, "Por favor, introduce una temperatura", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Lógica de conversión de temperatura
    private fun convertTemperature(value: Double, from: String, to: String): Double {
        if (from == to) return value

        // 1. Convertir todo a Celsius como paso intermedio
        val tempInCelsius = when {
            from.startsWith("Celsius") -> value
            from.startsWith("Fahrenheit") -> (value - 32) * 5 / 9
            from.startsWith("Kelvin") -> value - 273.15
            else -> value
        }

        // 2. Convertir de Celsius a la unidad destino
        return when {
            to.startsWith("Celsius") -> tempInCelsius
            to.startsWith("Fahrenheit") -> (tempInCelsius * 9 / 5) + 32
            to.startsWith("Kelvin") -> tempInCelsius + 273.15
            else -> tempInCelsius
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}