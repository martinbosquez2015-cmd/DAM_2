package com.example.calculadoradebiciestosytemperatura

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.calculadoradebiciestosytemperatura.databinding.ActivityLeapYearBinding

class LeapYearActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLeapYearBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLeapYearBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Calculadora de Bisiestos"

        binding.btnCheckYear.setOnClickListener {
            val yearInput = binding.etYear.text.toString()

            if (yearInput.isNotEmpty()) {
                val year = yearInput.toInt()
                if (isLeapYear(year)) {
                    binding.tvLeapResult.text = "El año $year ES bisiesto."
                } else {
                    binding.tvLeapResult.text = "El año $year NO es bisiesto."
                }
            } else {
                Toast.makeText(this, "Por favor, introduce un año válido", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Regla del año bisiesto
    private fun isLeapYear(year: Int): Boolean {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}