package com.example.calculadoradebiciestosytemperatura

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.calculadoradebiciestosytemperatura.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Botón para ir a la calculadora de bisiestos
        binding.btnLeapYear.setOnClickListener {
            val intent = Intent(this, LeapYearActivity::class.java)
            startActivity(intent)
        }

        // Botón para ir a la calculadora de temperaturas
        binding.btnTemperature.setOnClickListener {
            val intent = Intent(this, TemperatureActivity::class.java)
            startActivity(intent)
        }
    }
}