package com.example.lightsoutchallenge

import android.content.res.ColorStateList
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private val estadoTabla = Array(3){BooleanArray(3){false} }

    private lateinit var buttonsGrid: Array<Array<Button>>

    private var contador = 0
    private var segundos = 0
    private var cronometroCorre = false
    private val manejoTiempo = Handler(Looper.getMainLooper())
    private lateinit var timerRunnable: Runnable

    private lateinit var tvMoves: TextView
    private lateinit var tvTimer: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //enlazar textview con los del xml
        tvMoves= findViewById(R.id.tvMoves)
        tvTimer = findViewById(R.id.tvTimer)

        setUpEscuchaTabla()
        setUpCronometro()
        //el boton de reiniciar
        val btnReset = findViewById<Button>(R.id.btnReset)
        btnReset.setOnClickListener {
            reiniciar()
        }
        // el boton para una aprtida aleatoria
        findViewById<Button>(R.id.btnRandom).setOnClickListener {
            empezarAleatorio()
        }
    }

    private fun setUpEscuchaTabla(){
        val buttonIds = arrayOf(
            arrayOf(R.id.btn00, R.id.btn01, R.id.btn02),
            arrayOf(R.id.btn10, R.id.btn11, R.id.btn12),
            arrayOf(R.id.btn20, R.id.btn21, R.id.btn22)
        )

        buttonsGrid = Array(3) { row->
            Array(3) { col ->
                val button = findViewById<Button>(buttonIds[row][col])
                button.setOnClickListener {
                    enCeldaClickada(row, col)
                }
                button
            }
        }
        actualizarUI()

        for(row in 0..2){
            for(col in 0..2){
                val button = findViewById<Button>(buttonIds[row][col])
                button.setOnClickListener { enCeldaClickada(row, col) }
            }
        }
    }

    private fun setUpCronometro(){
        timerRunnable = object : Runnable{
            override fun run() {
                if (cronometroCorre){
                    segundos++
                    tvTimer.text = "Tiempo: ${segundos}s"
                    manejoTiempo.postDelayed(this,1000) // Ejecutandose cada 1 segundo
                }

            }
        }
    }

    private fun correrCron(){
        if(!cronometroCorre){
            cronometroCorre = true
            manejoTiempo.postDelayed(timerRunnable, 1000)
        }
    }

    private fun pararCron(){
        cronometroCorre = false
        manejoTiempo.removeCallbacks(timerRunnable)
    }

    private fun resetearCron(){
        pararCron()
        segundos=0
        tvTimer.text = "Tiempo: 0s"
    }

    private fun enCeldaClickada(row:Int, col: Int){
        //arrancar el temporizador con el primer movimiento del usuario
        if(!cronometroCorre && contador== 0 && !revisarVictoria()){
            correrCron()
        }
        //se aplica el movimiento y se suma el contador
        aplicarMovimiento(row, col)
        contador++
        actualizarUI()
        //comprovacion de ganancia
        if(revisarVictoria()){
            mostrarAvisoVictoria()
        }


    }

    private fun aplicarMovimiento(row: Int, col:Int){
        cambiarCelda(row, col)
        if(row -1>=0) cambiarCelda(row -1, col)
        if(row +1 <= 2) cambiarCelda(row+1,col)
        if(col-1 >=0) cambiarCelda(row, col-1)
        if (col +1 <= 2 ) cambiarCelda(row, col+1)

    }

    private fun cambiarCelda(row:Int, col:Int){
        estadoTabla[row][col] = !estadoTabla[row][col]
    }

    private fun actualizarUI(){
        val colorPrim = ContextCompat.getColor(this, R.color.state_prim)
        val colorSec = ContextCompat.getColor(this, R.color.state_sec)

        for(row in 0..2){
            for(col in 0..2){
                val colorToApply = if (estadoTabla[row][col]) colorSec else colorPrim
                buttonsGrid[row][col].backgroundTintList = ColorStateList.valueOf(colorToApply)
            }
        }
        //actualizar el texto del contador con los movimientos
        tvMoves.text = "Movimientos: $contador"
    }
    private fun reiniciar(){
        resetearCron()
        contador = 0
        for(row in 0..2){
            for(col in 0..2){
                estadoTabla[row][col] = false
            }
        }
        actualizarUI()
        Toast.makeText(this,"Partida reiniciada", Toast.LENGTH_SHORT).show()

    }

    private fun empezarAleatorio(){
        resetearCron()
        contador = 0
        //nos aseguramos de que empiece limpio
        for (row in 0..2) {
            for (col in 0..2) {
                estadoTabla[row][col] = false
            }
        }
        //se hacen movimientos aleatorios

        val randomMoves = Random.nextInt(5, 9)
        for (i in 0 until randomMoves) {
            val r = Random.nextInt(0, 3)
            val c = Random.nextInt(0, 3)
            aplicarMovimiento(r, c) // Usamos applyMove sin sumar al contador de usuario
        }
        //se reinicia el contador

        contador = 0
        actualizarUI()
        Toast.makeText(this, "la partida aleatoria está generada weon",Toast.LENGTH_SHORT).show()

    }

    private fun revisarVictoria(): Boolean{
        return estadoTabla.all {row -> row.all { it }}
    }

    private fun mostrarAvisoVictoria(){
        AlertDialog.Builder(this).setTitle("Ganaste weon!").setMessage("lo lograste mano").setPositiveButton("Volver a jugar"){ _, _ ->reiniciar()}.setCancelable(false).show()


    }

}