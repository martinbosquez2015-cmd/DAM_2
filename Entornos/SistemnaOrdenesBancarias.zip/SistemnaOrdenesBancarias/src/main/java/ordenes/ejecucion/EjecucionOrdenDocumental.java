package ordenes.ejecucion;

import ordenes.documentos.Movimientos;
import ordenes.documentos.Talon;
import ordenes.transferencia.OrdenDTO;
import ordenes.transferencia.SolicitudDTO;

import java.util.List;

public class EjecucionOrdenDocumental {
    public SolicitudDTO tramitar(OrdenDTO ordenDTO){
        SolicitudDTO solicitudDTO;

        if (!ordenDTO.getBanco().equals("")){
            try {
                int banco = Integer.parseInt(ordenDTO.getBanco());
            }catch(Exception e ){
                throw new OrdenNoValida("Fallo en el banco");
            }
        int banco = Integer.parseInt(ordenDTO.getBanco());
        if (banco>999 || banco<200){
            throw new OrdenNoValida("Fallo en el banco");
        }
        }

        if (ordenDTO.getTipoOrden().equals("")){
            solicitudDTO = new SolicitudDTO(List.of(new Talon(), new Movimientos()));
        }else if (ordenDTO.getTipoOrden().equals("Movimientos")){
            solicitudDTO = new SolicitudDTO(List.of(new Movimientos()));
        }
        else {
            solicitudDTO = new SolicitudDTO(List.of(new Talon()));
        }
        return solicitudDTO;

    }

}
