package ordenes.ejecucion;

import ordenes.documentos.Movimientos;
import ordenes.documentos.Talon;
import ordenes.transferencia.OrdenDTO;
import ordenes.transferencia.SolicitudDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestEjecucion {
    EjecucionOrdenDocumental ejecucionOrdenDocumental;
    @BeforeEach
    public void tearUp(){
        ejecucionOrdenDocumental = new EjecucionOrdenDocumental();
    }

    @Test
    public void casoValidoBancoBlancoTalonario(){
        OrdenDTO ordenDTO = new OrdenDTO("", 3589, 50000,"gordo","Talonario");
        // var OrdenDTO esto tambien vale, pero si no està en muchas lineas creo, la verdad no entendí xd


        EjecucionOrdenDocumental ejecucionOrdenDocumental = new EjecucionOrdenDocumental();

        SolicitudDTO solicitudDTO = ejecucionOrdenDocumental.tramitar(ordenDTO);

        // evaluo que la lista en solicitudDTO tiene un solo elemento,
        Assertions.assertEquals(1, solicitudDTO.getDocumentos().size());
        // evaluo que el elemento presente en la lista es un documento de tipo talon
        Assertions.assertTrue(solicitudDTO.getDocumentos().getFirst() instanceof Talon);


    }
    @Test
    public void casoValidoBancoBlancoTalonarioMovimientos(){
        OrdenDTO ordenDTO = new OrdenDTO("", 3589, 50000,"gordo","");
        // var OrdenDTO esto tambien vale, pero si no està en muchas lineas creo, la verdad no entendí xd


        EjecucionOrdenDocumental ejecucionOrdenDocumental = new EjecucionOrdenDocumental();

        SolicitudDTO solicitudDTO = ejecucionOrdenDocumental.tramitar(ordenDTO);

        // evaluo que la lista en solicitudDTO tiene un solo elemento,
        Assertions.assertEquals(2, solicitudDTO.getDocumentos().size());
        // evaluo que el elemento primero en la lista es un documento de tipo talon
        Assertions.assertTrue(solicitudDTO.getDocumentos().getFirst() instanceof Talon);
        // evaluo que el elemento segundo en la lista es un elemento tipo movimientos
        Assertions.assertTrue(solicitudDTO.getDocumentos().getLast() instanceof Movimientos);


    }

    @Test
    public void casoValidoBancoValidoMovimientos(){
        OrdenDTO ordenDTO = new OrdenDTO("359", 3589, 50000,"gordo","Movimientos");
        // var OrdenDTO esto tambien vale, pero si no està en muchas lineas creo, la verdad no entendí xd


        EjecucionOrdenDocumental ejecucionOrdenDocumental = new EjecucionOrdenDocumental();

        SolicitudDTO solicitudDTO = ejecucionOrdenDocumental.tramitar(ordenDTO);

        // evaluo que la lista en solicitudDTO tiene un solo elemento,
        Assertions.assertEquals(1, solicitudDTO.getDocumentos().size());
        // evaluo que el elemento primero en la lista es un documento de tipo talon
        Assertions.assertTrue(solicitudDTO.getDocumentos().getFirst() instanceof Movimientos);


    }

    @Test
    public void casoInvalidoBancoValorFueraRangoArriba(){
        OrdenDTO ordenDTO = new OrdenDTO("1000", 3589, 50000,"gordo","");

        Assertions.assertThrows(OrdenNoValida.class,() -> ejecucionOrdenDocumental.tramitar(ordenDTO));
    }
    @Test
    public void casoInvalidoBancoValorFueraRangoabajo(){
        OrdenDTO ordenDTO = new OrdenDTO("187", 3589, 50000,"gordo","");

        Assertions.assertThrows(OrdenNoValida.class,() -> ejecucionOrdenDocumental.tramitar(ordenDTO));
    }
    @Test
    public void casoInvalidoBancoValorNoNumerico(){
        OrdenDTO ordenDTO = new OrdenDTO("Boniato", 3589, 50000,"gordo","");

        Assertions.assertThrows(OrdenNoValida.class,() -> ejecucionOrdenDocumental.tramitar(ordenDTO));
    }

}
